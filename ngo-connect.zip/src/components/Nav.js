const Nav = () => {
    return (
        <div className="Top-Nav">
     
            <h3 className="Heading">NGO Connect</h3>
            
        </div>
      );
}
 
export default Nav;